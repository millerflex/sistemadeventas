<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Producto;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        //vamos a crear un rol para que cuando se registre el usuario con la empresa este (usuario) tenga ya un rol predeterminado

        $administrador = Role::create(['name'=>'ADMINISTRADOR']);

        Producto::factory()->count(100)->create();
    }
}
