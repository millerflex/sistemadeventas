

<?php $__env->startSection('content_header'); ?>
    <h1>Configuraciones/Editar</h1>
    <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card card-outline card-success">

        
        
            <div class="card-header <?php echo e(config('adminlte.classes_auth_header', '')); ?>">
                <h3 class="card-title float-none">
                    <b>Datos registrados</b>
                </h3>
            </div>
        

        
        <div class="card-body <?php echo e($auth_type ?? 'login'); ?>-card-body <?php echo e(config('adminlte.classes_auth_body', '')); ?>">
            <form action="<?php echo e(url('/admin/configuracion', $empresa->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="logo">Logo</label>
                            <input type="file" class="form-control" name="logo" accept=".jpg, .jpeg, .png" id="file">
                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color:red;"> <?php echo e($message); ?> </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <!--Script para previsualizar la imagen a cargar en la base de datos-->
                            <center>
                                <output style="padding= 10px" id="list">
                                    <img src="<?php echo e(asset('storage/images/'.$empresa->logo)); ?>" width="80%" alt="logo">
                                </output>
                            </center>
                            <br>
                            <br>
                            <script>
                                function archivo(evt){
                                    var files = evt.target.files;
                                    //obtenemos la imagen del campo "file"
                                    for(var i=0,f; f= files[i]; i++){
                                        //sólo admito imágenes
                                        if(!f.type.match('image.*')){
                                            continue
                                        }

                                        var reader = new FileReader()
                                        reader.onload = (function (theFile){
                                            return function(e){
                                                //Insertamos la imagen
                                                document.getElementById("list").innerHTML = ['<img class="thumb thumbnail" src="', e.target.result, '" width="100%" title= "',escape(theFile.name), '"/>'].join('')
                                            }
                                        }) (f)
                                        reader.readAsDataURL(f)
                                    }
                                }
                                    document.getElementById('file').addEventListener('change', archivo, false)
                            </script>
                        <!--Script para previsualizar la imagen a cargar en la base de datos-->
                        </div>
                    </div>

                    <div class="col-md-9">

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="pais">País</label>
                                    <select name="pais" id="select_pais" class="form-control" id="">
                                        <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pais->id); ?>" <?php echo e($empresa->pais == $pais->id ? 'selected' : ''); ?>><?php echo e($pais->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="departamento">Estado/Provincia/Región</label>
                                        <select name="estado" id="select_departamento2" class="form-control">
                                            <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  value="<?php echo e($departamento->id); ?>" <?php echo e($empresa->departamento == $departamento->id ? 'selected' : ''); ?>><?php echo e($departamento->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div id="respuesta_pais">

                                        </div>

                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="ciudad">Ciudad</label>
                                        <select name="ciudad" id="select_ciudad_2" class="form-control">
                                            <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  value="<?php echo e($ciudad->id); ?>" <?php echo e($empresa->ciudad == $ciudad->id ? 'selected' : ''); ?>><?php echo e($ciudad->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div id="respuesta_estado">

                                        </div>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="nombre_empresa">Nombre de la empresa</label>
                                    <input type="text" value="<?php echo e($empresa->nombre_empresa); ?>" class="form-control" name="nombre_empresa" required>
                                    <?php $__errorArgs = ['nombre_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tipo_empresa">Tipo de la empresa</label>
                                    <input type="text" value="<?php echo e($empresa->tipo_empresa); ?>" class="form-control" name="tipo_empresa" required>
                                    <?php $__errorArgs = ['tipo_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="nit">NIT</label>
                                    <input type="text" value="<?php echo e($empresa->nit); ?>" name="nit" class="form-control" required>
                                    <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="moneda">Moneda</label>
                                    <select name="moneda" class="form-control">
                                        <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($moneda->id); ?>" <?php echo e($empresa->moneda == $moneda->id ? 'selected' : ''); ?>><?php echo e($moneda->symbol); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="nombre_impuesto">Nombre del impuesto</label>
                                    <input type="text" value="<?php echo e($empresa->nombre_impuesto); ?>" class="form-control" name="nombre_impuesto" required>
                                    <?php $__errorArgs = ['nombre_impuesto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="cantidad_impuesto">%</label>
                                    <input type="number" value="<?php echo e($empresa->cantidad_impuesto); ?>" name="cantidad_impuesto" class="form-control" required>
                                    <?php $__errorArgs = ['cantidad_impuesto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="telefono">Teléfono de la empresa</label>
                                    <input type="text" value="<?php echo e($empresa->telefono); ?>" class="form-control" name="telefono" required>
                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="correo">Correo de la empresa</label>
                                    <input type="email" value="<?php echo e($empresa->correo); ?>" class="form-control" name="correo" required>
                                    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label for="direccion">Dirección</label>
                                    <input id="pac-input" value="<?php echo e($empresa->direccion); ?>" type="text" name="direccion" class="form-control" placeholder="buscar..." required>
                                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="codigo_postal">Código Postal</label>
                                    <select name="codigo_postal" class="form-control" id="" required>
                                        <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pais->phone_code); ?>" <?php echo e($empresa->codigo_postal == $pais->phone_code ? 'selected' : ''); ?>><?php echo e($pais->phone_code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>
                                </div>
                            </div>

                        </div>

                        <hr>

                            <div class="row">
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-lg btn-success btn-block">Actualizar datos</button>
                                </div>
                            </div>

                    </div>

                </div>

            </form>
        </div>

        
        <?php if (! empty(trim($__env->yieldContent('auth_footer')))): ?>
            <div class="card-footer <?php echo e(config('adminlte.classes_auth_footer', '')); ?>">
                <?php echo $__env->yieldContent('auth_footer'); ?>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<!--- Script para que al seleccionar un país se carguen sus provincias/estados respectivas --->
<script>
    $('#select_pais').on('change', function (){
        
        //El valor del select que tiene los paises lo almaceno en la variable "pais"
        var id_pais = $('#select_pais').val()
        //lert(pais)
        if(id_pais){
            $.ajax({
                url:"<?php echo e(url('/admin/configuracion/pais')); ?>"+ '/' +id_pais,
                type:"GET",
                success: function (data){
                    $('#select_departamento2').css('display', 'none')
                    $('#respuesta_pais').html(data);
                }

            })
        }else{
            alert("Debe seleccionar un país")
        }
    })
</script>

<!--- Script para que al seleccionar un estado/provincia se carguen sus ciudades respectivas --->
<script>
    $(document).on('change', '#select_estado', function () {
        var id_estado = $(this).val()
        //alert(id_estado)

        if(id_estado){
            $.ajax({
                url:"<?php echo e(url('/admin/configuracion/estado')); ?>"+ '/' +id_estado,
                type:"GET",
                success: function (data){
                    $('#select_ciudad_2').css('display', 'none')
                    $('#respuesta_estado').html(data);
                    
                }

            })
        }else{
            alert("Debe seleccionar una Ciudad")
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views\admin\configuraciones\edit.blade.php ENDPATH**/ ?>