

<?php $__env->startSection('content_header'); ?>
    <h1><b>Modificación de la venta</b></h1>
    <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-9">
                <div class="card card-outline card-success">
                    <div class="card-header">
                        <h3 class="card-title">Ingrese los datos</h3>
                        <!-- /.card-tools -->

                    </div>
                    <!-- /.card-header -->
                    

                    <div class="card-body">
                        <form action="<?php echo e(url('/admin/ventas', $venta->id)); ?>" id="form_venta" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">

                                        <div class="col-md-8">
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="cantidad">Cántidad</label>
                                                        <input type="number" id="cantidad" style="text-align: center; background-color:#f0e2c0" value="1" class="form-control" required>
                                                        <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="codigo">Código</label>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="bi bi-upc"></i></span>
                                                        </div>
                                                        <input id="codigo" type="text" class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <div style="height: 32px"></div>

                                                        <button type="button"
                                                                class="btn btn-primary w-md-auto mb-2 mb-md-0 w-100 "
                                                                data-toggle="modal"
                                                                data-target="#productoModal">
                                                                <i class="bi bi-search"></i>
                                                        </button>

                                                        <button id="btn-agregar" type="button" class="btn btn-warning  w-100 d-block d-md-none" onclick="agregarAlCarrito()">
                                                            <i class="bi bi-cart-plus"></i>
                                                        </button>

                                                        <!---Modal para la búsqueda de productos--->
                                                        
                                                        <!-- Modal -->
                                                        <div class="modal fade" id="productoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-xl">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">Listado de productos</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                        <div class="modal-body">
                                                                            <table id="table_products" class="table table-striped table-hover table-sm dt-responsive nowrap" style="width: 100%">
                                                                                <thead class="thead-light">
                                                                                    <tr>
                                                                                        <th scope="col" style="text-align: center">Nro</th>
                                                                                        <th scope="col" style="text-align: center">Acción</th>
                                                                                        <th scope="col" style="text-align: center">Categoría</th>
                                                                                        <th scope="col" style="text-align: center">Código</th>
                                                                                        <th scope="col" style="text-align: center">Nombre</th>
                                                                                        <th scope="col" style="text-align: center">Descripción</th>
                                                                                        <th scope="col" style="text-align: center">Stock</th>
                                                                                        <th scope="col" style="text-align: center">Precio compra</th>
                                                                                        <th scope="col" style="text-align: center">Precio venta</th>
                                                                                        <th scope="col" style="text-align: center">Imagen</th>
                                                                                    </tr>
                                                                                </thead>
                                                                                <tbody>
                                                                                    <?php $contador_productos = 1; ?>
                                                                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <tr>
                                                                                            <td style="text-align: center; vertical-align:middle"><?php echo e($contador_productos++); ?></td>
                                                                                            <td style="text-align: center; vertical-align:middle">
                                                                                                <button type="button" class="btn btn-info btn-sm btn-seleccionar" data-id="<?php echo e($producto->codigo); ?>">Seleccionar</button>
                                                                                            </td>
                                                                                            <td style="text-align: center; vertical-align:middle"><?php echo e($producto->categoria->nombre); ?></td>
                                                                                            <td style="text-align: center; vertical-align:middle"><?php echo e($producto->codigo); ?></td>
                                                                                            <td style="text-align: center; vertical-align:middle"><?php echo e($producto->nombre); ?></td>
                                                                                            <td style="text-align: center; vertical-align:middle">
                                                                                                <!--Este fragmento de código lo que hace es limitar hasta 100 caracteres un texto largo-->
                                                                                                <?php echo \Illuminate\Support\Str::limit($producto->descripcion, 100, '...'); ?>

                                                                                            </td>
                                                                                            <td style="text-align: center; background-color:rgb(235, 225, 213); vertical-align:middle"><?php echo e($producto->stock); ?></td>
                                                                                            <td style="text-align: center; vertical-align:middle"><?php echo e($producto->precio_compra); ?></td>
                                                                                            <td style="text-align: center; vertical-align:middle"><?php echo e($producto->precio_venta); ?></td>
                                                                                            <td style="text-align: center; vertical-align:middle">
                                                                                                <img src="<?php echo e(asset('storage/'.$producto->imagen)); ?>" width="80px" alt="logo">
                                                                                            </td>
                                                                                        </tr>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    
                                                                                </tbody>
                                                                                
                                                                            </table>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!---Modal para la búsqueda de productos--->

                                                        <a href="<?php echo e(url('/admin/productos/create')); ?>" type="button" class="btn btn-success w-md-auto mt-2 mb-md-0 w-100"><i class="bi bi-plus-circle"></i></a>
                                                    </div>
                                                </div>

                                            </div>
                                            <br>
                                            <div class="row">
                                                <table class="table table-striped table-sm table-bordered table-group-divider table-hover dt-responsive nowrap" style="width: 100%">
                                                    <thead class="table-primary">
                                                        <tr style="text-align: center">
                                                            <th>Nro</th>
                                                            <th>Código</th>
                                                            <th>Cántidad</th>
                                                            <th>Nombre</th>
                                                            <th>Costo</th>
                                                            <th>Total</th>
                                                            <th>Acción</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        <?php $contador = 1; $total_cantidad = 0; $total_venta = 0; ?>
                                                        
                                                        <?php $__currentLoopData = $venta->detallesVenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle_venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td style="text-align: center"><?php echo e($contador++); ?></td>
                                                                <td style="text-align: center"><?php echo e($detalle_venta->producto->codigo); ?></td>
                                                                <td style="text-align: center"><?php echo e($detalle_venta->cantidad); ?></td>
                                                                <td style="text-align: center"><?php echo e($detalle_venta->producto->nombre); ?></td>
                                                                <td style="text-align: center"><?php echo e($detalle_venta->producto->precio_venta); ?></td>
                                                                <td style="text-align: center"><?php echo e($total = $detalle_venta->producto->precio_venta * $detalle_venta->cantidad); ?></td>
                                                                <td style="text-align: center">
                                                                    <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="<?php echo e($detalle_venta->id); ?>"><i class="bi bi-trash3-fill"></i></button>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                                $total_cantidad += $detalle_venta->cantidad;
                                                                $total_venta += $total;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>

                                                    <tfoot>
                                                        <tr>
                                                            <td style="text-align: right" colspan="2"><b>Total cántidad</b></td>
                                                            <td style="text-align: center"><b><?php echo e($total_cantidad); ?></b></td>

                                                            <td style="text-align: right" colspan="2"><b>Precio Total</b></td>
                                                            <td style="text-align: center"><b><?php echo e($total_venta); ?></b></td>
                                                        </tr>
                                                    </tfoot>

                                                </table>
                                            </div>

                                        </div>

                                        <div class="col-md-4">

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#clienteModal">Buscar cliente</button>
                                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#cliente-create-Modal"><i class="bi bi-plus-circle"></i></button>
                                                </div>

                                                <!-- Modal para la búsqueda de clientes-->
                                                <div class="modal fade" id="clienteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Listado de clientes</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                                <div class="modal-body">
                                                                    <table id="table_clientes" class="table table-striped table-hover table-sm dt-responsive nowrap" style="width: 100%">
                                                                        <thead class="thead-light">
                                                                            <tr>
                                                                                <th scope="col" style="text-align: center">Nro</th>
                                                                                <th scope="col" style="text-align: center">Acción</th>
                                                                                <th scope="col" style="text-align: center">Nombre Cliente</th>
                                                                                <th scope="col" style="text-align: center">Código</th>
                                                                                <th scope="col" style="text-align: center">Teléfono</th>
                                                                                <th scope="col" style="text-align: center">Email</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php $contador_clientes = 1; ?>
                                                                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <tr>
                                                                                    <td style="text-align: center; vertical-align:middle"><?php echo e($contador_clientes++); ?></td>
                                                                                    <td style="text-align: center; vertical-align:middle">
                                                                                        <button type="button" class="btn btn-info btn-sm btn-seleccionar-cliente" data-id="<?php echo e($cliente->id); ?>" data-codigo="<?php echo e($cliente->codigo); ?>" data-nombrecliente="<?php echo e($cliente->nombre_cliente); ?>">Seleccionar</button>
                                                                                    </td>
                                                                                    <td style="text-align: center; vertical-align:middle"><?php echo e($cliente->nombre_cliente); ?></td>
                                                                                    <td style="text-align: center; vertical-align:middle"><?php echo e($cliente->codigo); ?></td>
                                                                                    <td style="text-align: center; vertical-align:middle"><?php echo e($cliente->telefono); ?></td>
                                                                                    <td style="text-align: center; vertical-align:middle"><?php echo e($cliente->email); ?></td>
                                                                                </tr>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            
                                                                        </tbody>
                                                                        
                                                                    </table>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                                </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!---Modal para la búsqueda de clientes--->

                                                <!-- Modal para crear clientes-->
                                                <div class="modal fade" id="cliente-create-Modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Registrar nuevo cliente</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                                <div class="modal-body">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <label for="nombre_cliente">Nombre del cliente</label>
                                                                                    <input type="text" id="nombre" value="<?php echo e(old('nombre_cliente')); ?>" class="form-control">
                                                                                    <?php $__errorArgs = ['nombre_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                            </div>
                                            
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <label for="codigo">Código del cliente</label>
                                                                                    <input type="text" id="cod" value="<?php echo e(old('codigo')); ?>" class="form-control">
                                                                                    <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                            </div>
                                            
                                                                        </div>
                                            
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <label for="telefono">Teléfono</label>
                                                                                    <input type="text" id="telefono" value="<?php echo e(old('telefono')); ?>" class="form-control">
                                                                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                            </div>
                                            
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <label for="email">Correo</label>
                                                                                    <input type="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control">
                                                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                            </div>
                                            
                                                                        </div>
                                            
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" onclick="guardar_cliente()" class="btn btn-primary"><i class="bi bi-save"></i> Registrar</button>
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                                </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!---Modal para crear clietes--->

                                            </div>

                                            <hr>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="">Nombre del cliente</label>
                                                    <input type="text" id="nombre_cliente_select" class="form-control" value="<?php echo e($venta->cliente->nombre_cliente ?? 'S/N'); ?>" disabled>
                                                    <input type="text" id="id_cliente" class="form-control" name="cliente_id" value="<?php echo e($venta->cliente->id ?? ''); ?>" hidden>
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="">Código del cliente</label>
                                                    <input type="text" id="codigo_cliente_select" class="form-control" value="<?php echo e($venta->cliente->codigo ?? '0'); ?>" disabled>
                                                </div>
                                            </div>

                                            <hr>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="fecha">Fecha de venta</label>
                                                        <input type="date" name="fecha_venta" value="<?php echo e(old('fecha', $venta->fecha_venta)); ?>" class="form-control">
                                                        <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="total_venta">Costo Total</label>
                                                        <input type="text" style="text-align: center; color:rgb(0, 0, 0); background-color:bisque" name="precio_total" value="<?php echo e($total_venta); ?>" class="form-control" readonly>
                                                        <?php $__errorArgs = ['total_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                            </div>

                                            <hr>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button type="submit" class="btn btn-success btn-block"><i class="bi bi-arrow-clockwise"></i> Actualizar venta</button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                        
                                    </div>

                                </div>

                            </div>

                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
        <script>

        //Función para agregar productos al carrito pero con el botón agregar que va a aparecer cuando el sistema esté en móvil
            function agregarAlCarrito(){

                    var codigo = $('#codigo').val()
                    var cantidad = $('#cantidad').val()
                    var id_venta = '<?php echo e($venta->id); ?>'
            
                    if(codigo.length > 0){
                        $.ajax({
                            url: "<?php echo e(route('admin.detalle.ventas')); ?>",
                            method: 'POST',
                            data:{
                                _token:'<?php echo e(csrf_token()); ?>',
                                codigo: codigo,
                                cantidad: cantidad,
                                id_venta: id_venta
                            },
                            success:function(response){
                                if(response.success){
                                    Swal.fire({
                                    position: "top-end",
                                    icon: "success",
                                    title: "El producto se agregó correctamente",
                                    showConfirmButton: false,
                                    timer: 4000
                                    });

                                    location.reload(); //La página se va a refrescar automáticamente al registrarse el producto

                                }else{
                                    Swal.fire({
                                    position: "top-end",
                                    icon: "error",
                                    title: "Producto no encontrado en la base de datos",
                                    showConfirmButton: false,
                                    timer: 4000
                                    });
                                }
                            },

                            error:function(error){
                                alert (error);
                            }
                        })
                    }
            }    
            
        //Script para registrar a un cliente cuando hace una compra por primera vez desde el formulario de ventas
        function guardar_cliente(){

            var nombre_cliente = $('#nombre').val()
            var codigo = $('#cod').val()
            var telefono = $('#telefono').val()
            var email = $('#email').val()

            $.ajax({
                url: '<?php echo e(route("admin.ventas.cliente.store")); ?>',
                method: 'POST',
                data:{
                    _token: '<?php echo e(csrf_token()); ?>',
                    nombre_cliente: nombre_cliente,
                    codigo: codigo,
                    telefono: telefono,
                    email: email
                },
                success: function(response){
                    if(response.success){
                                    Swal.fire({
                                    position: "top-end",
                                    icon: "success",
                                    title: "Cliente registrado correctamente",
                                    showConfirmButton: false,
                                    timer: 6000
                                    });

                                    location.reload(); //La página se va a refrescar automáticamente al registrarse el producto

                                }
                },
                error: function(xhr, status, error){
                    console.log(xhr.responseJSON);
                    alert('No se pudo agregar al cliente' + xhr.responseJSON.message)
                }
            })
        } 

            //Función para que al apretar el botón "seleccionar" se ingrese el nombre del cliente dentro del input
            $('.btn-seleccionar-cliente').click(function(){
                var id_cliente = $(this).data('id')
                var nombre_cliente = $(this).data('nombrecliente')
                var codigo = $(this).data('codigo')

                $('#nombre_cliente_select').val(nombre_cliente)
                $('#codigo_cliente_select').val(codigo)
                $('#id_cliente').val(id_cliente)
                $('#clienteModal').modal('hide');
                
                // alert(nombre_cliente)

            })
            //Función para que al apretar el botón "seleccionar" se ingrese el nombre del cliente dentro del input
            

            //Función para que al apretar el botón "seleccionar" el código del producto se pase al input "código"
            $('.btn-seleccionar').click(function(){
                var id_producto = $(this).data('id')
                $('#codigo').val(id_producto)
                $('#productoModal').modal('hide');
                $('#productoModal').on('hidden.bs.modal', function(){
                    $('#codigo').focus()
                });
                
                //alert(id)

            })

            //Función para eliminar los registros de la tabla
            $('.delete-btn').click( function(){
                var id = $(this).data('id')

                if(id){
                    $.ajax({
                            url: "<?php echo e(url('/admin/ventas/detalle')); ?>/"+id,
                            type: 'POST',
                            data:{
                                _token:'<?php echo e(csrf_token()); ?>',
                                _method:'DELETE'
                                
                            },
                            success:function(response){
                                if(response.success){
                                    Swal.fire({
                                    position: "top-end",
                                    icon: "success",
                                    title: "Producto eliminado",
                                    showConfirmButton: false,
                                    timer: 4000
                                    });

                                    location.reload(); //La página se va a refrescar automáticamente al registrarse el producto

                                }else{
                                    Swal.fire({
                                    position: "top-end",
                                    icon: "error",
                                    title: "El producto no se pudo eliminar",
                                    showConfirmButton: false,
                                    timer: 4000
                                    });
                                }
                            },

                            error:function(error){
                                alert (error)
                            }
                    })
                }
            })
            //Función para eliminar los registros de la tabla

            $('#codigo').focus() //Para que el cursor esté automáticamente dentro del INPUT del código

            //Script para que al presionar la tecla ENTER no se habilite el envío del formulario
            $('#form_venta').on('keypress', function(e){
                if(e.keyCode === 13){
                    e.preventDefault()
                }
            })
            //Script para que al presionar la tecla ENTER no se habilite el envío del formulario

            //Script para que al ingresar el código del producto, este se cargue de forma automática en la tabla
            $('#codigo').on('keyup', function(e){

                //13 equivale al código ascii que es igual al ENTER
                if(e.which === 13){

                    var codigo = $(this).val()
                    var cantidad = $('#cantidad').val()
                    var id_venta = '<?php echo e($venta->id); ?>'
            
                    if(codigo.length > 0){
                        $.ajax({
                            url: "<?php echo e(route('admin.detalle.ventas')); ?>",
                            method: 'POST',
                            data:{
                                _token:'<?php echo e(csrf_token()); ?>',
                                codigo: codigo,
                                cantidad: cantidad,
                                id_venta: id_venta
                            },
                            success:function(response){
                                if(response.success){
                                    Swal.fire({
                                    position: "top-end",
                                    icon: "success",
                                    title: "El producto se agregó correctamente",
                                    showConfirmButton: false,
                                    timer: 4000
                                    });

                                    location.reload(); //La página se va a refrescar automáticamente al registrarse el producto

                                }else{
                                    Swal.fire({
                                    position: "top-end",
                                    icon: "error",
                                    title: "Producto no encontrado en la base de datos",
                                    showConfirmButton: false,
                                    timer: 4000
                                    });
                                }
                            },

                            error:function(error){
                                alert (error);
                            }
                        })
                    }
                }
            
            })

        </script>

<script>
    $('#table_products').DataTable({
                            "responsive": true,
                            "autoWidth": false,
                        "pageLength": 5,
                                "language": {
                                    "emptyTable": "No hay información",
                                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Productos",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 Productos",
                                    "infoFiltered": "(Filtrado de _MAX_ total Productos)",
                                    "infoPostFix": "",
                                    "thousands": ",",
                                    "lengthMenu": "Mostrar _MENU_ Productos",
                                    "loadingRecords": "Cargando...",
                                    "processing": "Procesando...",
                                    "search": "Buscador:",
                                    "zeroRecords": "Sin resultados encontrados",
                                    "paginate": {
                                        "first": "Primero",
                                        "last": "Ultimo",
                                        "next": "Siguiente",
                                        "previous": "Anterior"
                                    }
                                },
                    })

                    $('#table_clientes').DataTable({
                            "responsive": true,
                            "autoWidth": false,
                        "pageLength": 5,
                                "language": {
                                    "emptyTable": "No hay información",
                                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Clientes",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 Clientes",
                                    "infoFiltered": "(Filtrado de _MAX_ total Clientes)",
                                    "infoPostFix": "",
                                    "thousands": ",",
                                    "lengthMenu": "Mostrar _MENU_ Clientes",
                                    "loadingRecords": "Cargando...",
                                    "processing": "Procesando...",
                                    "search": "Buscador:",
                                    "zeroRecords": "Sin resultados encontrados",
                                    "paginate": {
                                        "first": "Primero",
                                        "last": "Ultimo",
                                        "next": "Siguiente",
                                        "previous": "Anterior"
                                    }
                                },
                    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views\admin\ventas\edit.blade.php ENDPATH**/ ?>