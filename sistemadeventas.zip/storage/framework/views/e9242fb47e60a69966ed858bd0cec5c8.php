


<?php $__env->startSection('content_header'); ?>
    <h1><b>Listado de usuarios</b></h1>
    <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Usuarios registrados</h3>
                        <!-- /.card-tools -->

                        <div class="card-tools">
                            <a href="<?php echo e(url('/admin/usuarios/reporte')); ?>" class="btn btn-danger btn-sm" target="blank"><i class="bi bi-filetype-pdf"></i> Reporte</a>
                            <a href="<?php echo e(url('/admin/usuarios/create')); ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-circle"></i> Crear Usuario</a>
                        </div>

                    </div>
                    <!-- /.card-header -->
                    

                    <div class="card-body">
                        <table id="table_users" class="table table-striped table-hover table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="text-align: center">Nro</th>
                                    <th scope="col" style="text-align: center">Rol del Usuario</th>
                                    <th scope="col" style="text-align: center">Nombre del Usuario</th>
                                    <th scope="col" style="text-align: center">Email</th>
                                    <th scope="col" style="text-align: center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $contador_usuarios = 1; ?>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo e($contador_usuarios++); ?></td>
                                        
                                        <td style="text-align: center"><?php echo e($usuario->roles->pluck('name')->implode(', ')); ?></td>
                                        <td style="text-align: center"><?php echo e($usuario->name); ?></td>
                                        <td style="text-align: center"><?php echo e($usuario->email); ?></td>
                                        <td  style="text-align: center">
                                            <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                                <a href="<?php echo e(url('/admin/usuarios/show', $usuario->id )); ?>" class="btn btn-info btn-sm"><i class="bi bi-eye-fill"></i></a>
                                                <a href="<?php echo e(url('/admin/usuarios/'. $usuario->id .'/edit')); ?>" class="btn btn-success btn-sm"><i class="bi bi-pencil-fill"></i></a>
                                                <?php if($usuario->name !== 'Admin'): ?>
                                                    <form action="<?php echo e(url('/admin/usuarios', $usuario->id)); ?>" method="post" onclick="preguntar<?php echo e($usuario->id); ?> (event)"
                                                                        id="miFormulario<?php echo e($usuario->id); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger btn-sm" style="border-radius: 0px 3px 3px 0px"><i class="bi bi-trash3-fill"></i></button>
                                                        </form>
                                                        <script>
                                                            function preguntar<?php echo e($usuario->id); ?> (event){
                                                                event.preventDefault()
                                                                Swal.fire({
                                                                title: "¿Estás seguro de eliminar este registro de la base de datos?",
                                                                icon: "question",
                                                                showDenyButton: true,
                                                                showCancelButton: false,
                                                                confirmButtonText: "Eliminar",
                                                                denyButtonText: `No eliminar`
                                                                }).then((result) => {
                                                                /* Read more about isConfirmed, isDenied below */
                                                                if (result.isConfirmed) {
                                                                    var form = $('#miFormulario<?php echo e($usuario->id); ?>')
                                                                    form.submit()
                                                                }
                                                                });
                                                            }
                                                            
                                                        </script>
                                                <?php endif; ?>
                                                

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $('#table_users').DataTable({
                        "pageLength": 5,
                                "language": {
                                    "emptyTable": "No hay información",
                                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Usuarios",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 Usuarios",
                                    "infoFiltered": "(Filtrado de _MAX_ total Usuarios)",
                                    "infoPostFix": "",
                                    "thousands": ",",
                                    "lengthMenu": "Mostrar _MENU_ Usuarios",
                                    "loadingRecords": "Cargando...",
                                    "processing": "Procesando...",
                                    "search": "Buscador:",
                                    "zeroRecords": "Sin resultados encontrados",
                                    "paginate": {
                                        "first": "Primero",
                                        "last": "Ultimo",
                                        "next": "Siguiente",
                                        "previous": "Anterior"
                                    }
                                },
                            })
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views\admin\usuarios\index.blade.php ENDPATH**/ ?>