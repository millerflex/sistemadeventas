


<?php $__env->startSection('content_header'); ?>
    <h1><b>Listado de permisos</b></h1>
    <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Permisos registrados</h3>
                        <!-- /.card-tools -->

                        <div class="card-tools">
                            <a href="<?php echo e(url('/admin/permisos/create')); ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-circle"></i> Crear Permiso</a>
                        </div>

                    </div>
                    <!-- /.card-header -->
                    

                    <div class="card-body">
                        <table id="table_permission" class="table table-striped table-hover table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="text-align: center">Nro</th>
                                    <th scope="col" style="text-align: center">Nombre del Permiso</th>
                                    <th scope="col" style="text-align: center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $contador_permisos = 1; ?>
                                <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo e($contador_permisos++); ?></td>
                                        <td style="text-align: center"><?php echo e($permiso->name); ?></td>
                                        <td  style="text-align: center">
                                            <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                                <a href="<?php echo e(url('/admin/permisos/show', $permiso->id )); ?>" class="btn btn-info btn-sm"><i class="bi bi-eye-fill"></i></a>
                                                    <?php if($permiso->name !== "ADMINISTRADOR"): ?>
                                                        <a href="<?php echo e(url('/admin/permisos/'. $permiso->id .'/edit')); ?>" class="btn btn-success btn-sm"><i class="bi bi-pencil-fill"></i></a>
                                                    <?php endif; ?>
                                                    <?php if($permiso->name !== "ADMINISTRADOR"): ?>
                                                        <form action="<?php echo e(url('/admin/permisos', $permiso->id)); ?>" method="post" onclick="preguntar<?php echo e($permiso->id); ?> (event)"
                                                                        id="miFormulario<?php echo e($permiso->id); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger btn-sm" style="border-radius: 0px 3px 3px 0px"><i class="bi bi-trash3-fill"></i></button>
                                                        </form>
                                                        <script>
                                                            function preguntar<?php echo e($permiso->id); ?> (event){
                                                                event.preventDefault()
                                                                Swal.fire({
                                                                title: "¿Estás seguro de eliminar este registro de la base de datos?",
                                                                icon: "question",
                                                                showDenyButton: true,
                                                                showCancelButton: false,
                                                                confirmButtonText: "Eliminar",
                                                                denyButtonText: `No eliminar`
                                                                }).then((result) => {
                                                                /* Read more about isConfirmed, isDenied below */
                                                                if (result.isConfirmed) {
                                                                    var form = $('#miFormulario<?php echo e($permiso->id); ?>')
                                                                    form.submit()
                                                                }
                                                                });
                                                            }
                                                            
                                                        </script>
                                                    <?php endif; ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $('#table_permission').DataTable({
                        "pageLength": 5,
                                "language": {
                                    "emptyTable": "No hay información",
                                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Permisos",
                                    "infoEmpty": "Mostrando 0 a 0 de 0 Permisos",
                                    "infoFiltered": "(Filtrado de _MAX_ total Permisos)",
                                    "infoPostFix": "",
                                    "thousands": ",",
                                    "lengthMenu": "Mostrar _MENU_ Permisos",
                                    "loadingRecords": "Cargando...",
                                    "processing": "Procesando...",
                                    "search": "Buscador:",
                                    "zeroRecords": "Sin resultados encontrados",
                                    "paginate": {
                                        "first": "Primero",
                                        "last": "Ultimo",
                                        "next": "Siguiente",
                                        "previous": "Anterior"
                                    }
                                },
                    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views\admin\permisos\index.blade.php ENDPATH**/ ?>