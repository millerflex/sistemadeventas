

<?php $__env->startSection('content_header'); ?>
    <h1><b>Datos del cliente</b></h1>
    <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-8">
                <div class="card card-outline card-info">
                    <div class="card-header">
                        <h3 class="card-title">Datos registrados</h3>
                        <!-- /.card-tools -->

                    </div>
                    <!-- /.card-header -->
                    

                    <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <p><?php echo e($cliente->nombre_cliente); ?></p>
                                </div>

                                <div class="col-md-6">
                                    <p><?php echo e($cliente->codigo); ?></p>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <p><?php echo e($cliente->telefono); ?></p>
                                </div>

                                <div class="col-md-6">
                                    <p><?php echo e($cliente->email); ?></p>
                                </div>

                            </div>

                            <hr>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <a href="<?php echo e(url('/admin/clientes')); ?>" class="btn btn-secondary">Volver</a>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views\admin\clientes\show.blade.php ENDPATH**/ ?>