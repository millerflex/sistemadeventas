<select name="departamento" class="form-control" id="select_estado">
    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views\admin\empresas\cargar_estados.blade.php ENDPATH**/ ?>