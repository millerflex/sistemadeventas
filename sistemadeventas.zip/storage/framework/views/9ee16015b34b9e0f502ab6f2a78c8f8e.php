

<?php ( $dashboard_url = View::getSection('dashboard_url') ?? config('adminlte.dashboard_url', 'home') ); ?>

<?php if(config('adminlte.use_route_url', false)): ?>
    <?php ( $dashboard_url = $dashboard_url ? route($dashboard_url) : '' ); ?>
<?php else: ?>
    <?php ( $dashboard_url = $dashboard_url ? url($dashboard_url) : '' ); ?>
<?php endif; ?>

<?php $__env->startSection('adminlte_css'); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
    <?php echo $__env->yieldContent('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('classes_body'); ?><?php echo e(($auth_type ?? 'login') . '-page'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container">

        <br>

        
        <center>
            <img src="<?php echo e(asset('images/logo.jpg')); ?>" style="width: 250px" alt="">
        </center>
        <br>


        
        <div class="card <?php echo e(config('adminlte.classes_auth_card', 'card-outline card-primary')); ?>">

            
            
                <div class="card-header <?php echo e(config('adminlte.classes_auth_header', '')); ?>">
                    <h3 class="card-title float-none text-center">
                        <b>Registro de una nueva empresa</b>
                    </h3>
                </div>
            

            
            <div class="card-body <?php echo e($auth_type ?? 'login'); ?>-card-body <?php echo e(config('adminlte.classes_auth_body', '')); ?>">
                <form action="<?php echo e(url('crear_empresa/create')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="logo">Logo</label>
                                <input type="file" class="form-control" name="logo" accept=".jpg, .jpeg, .png" id="file" required>
                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small style="color:red;"> <?php echo e($message); ?> </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <!--Script para previsualizar la imagen a cargar en la base de datos-->
                                <output style="padding= 10px" id="list"></output>
                                <br>
                                <br>
                                <script>
                                    function archivo(evt){
                                        var files = evt.target.files;
                                        //obtenemos la imagen del campo "file"
                                        for(var i=0,f; f= files[i]; i++){
                                            //sólo admito imágenes
                                            if(!f.type.match('image.*')){
                                                continue
                                            }

                                            var reader = new FileReader()
                                            reader.onload = (function (theFile){
                                                return function(e){
                                                    //Insertamos la imagen
                                                    document.getElementById("list").innerHTML = ['<img class="thumb thumbnail" src="', e.target.result, '" width="100%" title= "',escape(theFile.name), '"/>'].join('')
                                                }
                                            }) (f)
                                            reader.readAsDataURL(f)
                                        }
                                    }
                                        document.getElementById('file').addEventListener('change', archivo, false)
                                </script>
                            <!--Script para previsualizar la imagen a cargar en la base de datos-->
                            </div>
                        </div>

                        <div class="col-md-9">

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pais">País</label>
                                        <select name="pais" id="select_pais" class="form-control" id="">
                                            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pais->id); ?>"><?php echo e($pais->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="departamento">Estado/Provincia/Región</label>
                                        
                                            <div id="respuesta_pais">

                                            </div>

                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="ciudad">Ciudad</label>

                                            <div id="respuesta_estado">

                                            </div>
                                    </div>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="nombre_empresa">Nombre de la empresa</label>
                                        <input type="text" value="<?php echo e(old('nombre_empresa')); ?>" class="form-control" name="nombre_empresa" required>
                                        <?php $__errorArgs = ['nombre_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tipo_empresa">Tipo de la empresa</label>
                                        <input type="text" value="<?php echo e(old('tipo_empresa')); ?>" class="form-control" name="tipo_empresa" required>
                                        <?php $__errorArgs = ['tipo_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="nit">NIT</label>
                                        <input type="text" value="<?php echo e(old('nit')); ?>" name="nit" class="form-control" required>
                                        <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="moneda">Moneda</label>
                                        <select name="moneda" class="form-control">
                                            <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($moneda->id); ?>"><?php echo e($moneda->symbol); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                    </div>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="nombre_impuesto">Nombre del impuesto</label>
                                        <input type="text" value="<?php echo e(old('nombre_impuesto')); ?>" class="form-control" name="nombre_impuesto" required>
                                        <?php $__errorArgs = ['nombre_impuesto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="cantidad_impuesto">%</label>
                                        <input type="number" value="<?php echo e(old('cantidad_impuesto')); ?>" name="cantidad_impuesto" class="form-control" required>
                                        <?php $__errorArgs = ['cantidad_impuesto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="telefono">Teléfono de la empresa</label>
                                        <input type="text" value="<?php echo e(old('telefono')); ?>" class="form-control" name="telefono" required>
                                        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="correo">Correo de la empresa</label>
                                        <input type="email" value="<?php echo e(old('correo')); ?>" class="form-control" name="correo" required>
                                        <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-9">
                                    <div class="form-group">
                                        <label for="direccion">Dirección</label>
                                        <input id="pac-input" value="<?php echo e(old('direccion')); ?>" type="text" name="direccion" class="form-control" placeholder="buscar..." required>
                                        <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small style="color:red;"> <?php echo e($message); ?> </small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <br>
                                        <div id="map" style="width: 100%; height: 400px"></div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="codigo_postal">Código Postal</label>
                                        <select name="codigo_postal" class="form-control" id="" required>
                                            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pais->phone_code); ?>"><?php echo e($pais->phone_code); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                    </div>
                                </div>

                            </div>

                            <hr>

                                <div class="row">
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-lg btn-primary btn-block">Crear empresa</button>
                                    </div>
                                </div>

                        </div>

                    </div>

                </form>
            </div>

            
            <?php if (! empty(trim($__env->yieldContent('auth_footer')))): ?>
                <div class="card-footer <?php echo e(config('adminlte.classes_auth_footer', '')); ?>">
                    <?php echo $__env->yieldContent('auth_footer'); ?>
                </div>
            <?php endif; ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    <?php echo $__env->yieldPushContent('js'); ?>
    <?php echo $__env->yieldContent('js'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAP_KEY')); ?>&libraries=places&callback=initAutocomplete" async defer></script>

    <!--Script para mostrar el mapa de Google Maps-->
    <script>
        function initMap() {
        // Ubicación inicial y configuración del mapa
        const initialLocation = { lat: 40.7128, lng: -74.0060 }; // Nueva York, por ejemplo
        const map = new google.maps.Map(document.getElementById("map"), {
            center: initialLocation,
            zoom: 13,
        });
    
        // Campo de búsqueda de lugares
        const input = document.getElementById("pac-input");
        const searchBox = new google.maps.places.SearchBox(input);
    
        // Ajuste del mapa según la búsqueda
        map.addListener("bounds_changed", () => {
            searchBox.setBounds(map.getBounds());
        });
    
        let markers = [];
        searchBox.addListener("places_changed", () => {
            const places = searchBox.getPlaces();
    
            if (places.length === 0) return;
    
            // Limpia los marcadores anteriores
            markers.forEach(marker => marker.setMap(null));
            markers = [];
    
            const bounds = new google.maps.LatLngBounds();
    
            places.forEach(place => {
                if (!place.geometry || !place.geometry.location) return;
    
                // Crear un marcador para cada lugar
                const marker = new google.maps.Marker({
                    map,
                    title: place.name,
                    position: place.geometry.location,
                });
                markers.push(marker);
    
                if (place.geometry.viewport) {
                    bounds.union(place.geometry.viewport);
                } else {
                    bounds.extend(place.geometry.location);
                }
            });
    
            map.fitBounds(bounds);
        });
    }
    
    // Inicializar el mapa cuando la página se carga
    window.onload = initMap;
    </script>

    <!--- Script para que al seleccionar un país se carguen sus provincias/estados respectivas --->
    <script>
        $('#select_pais').on('change', function (){
            
            //El valor del select que tiene los paises lo almaceno en la variable "pais"
            var id_pais = $('#select_pais').val()
            //lert(pais)
            if(id_pais){
                $.ajax({
                    url:"<?php echo e(url('/crear_empresa/pais')); ?>"+'/'+id_pais,
                    type:"GET",
                    success: function (data){
                        $('#respuesta_pais').html(data);
                    }

                })
            }else{
                alert("Debe seleccionar un país")
            }
        })
    </script>

<!--- Script para que al seleccionar un estado/provincia se carguen sus ciudades respectivas --->
    <script>
        $(document).on('change', '#select_estado', function () {
            var id_estado = $(this).val()
            //alert(id_estado)

            if(id_estado){
                $.ajax({
                    url:"<?php echo e(url('/crear_empresa/estado')); ?>"+'/'+id_estado,
                    type:"GET",
                    success: function (data){
                        $('#respuesta_estado').html(data);
                    }

                })
            }else{
                alert("Debe seleccionar una Ciudad")
            }
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistemadeventas\resources\views\admin\empresas\create.blade.php ENDPATH**/ ?>